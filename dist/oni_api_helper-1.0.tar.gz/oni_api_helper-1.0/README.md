# oni_api_helper para consumo de APIs
Consumo de APIs
código `hfnhnhf`
- item 1
- item 2
